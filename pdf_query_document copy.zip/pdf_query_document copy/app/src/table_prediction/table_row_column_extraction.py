import subprocess
import sys
import os
from app.utils.constant import PREDICT_ROW_COLUMN_STORE,PREDICT_IMAGE_STORE,PREDICT_WORD_STORE

# Add the current working directory to sys.path
# sys.path.append(os.getcwd())

def predict_table_row_col(predict_fld_path):
    # predict_fld_path = 'pdf_ouptut/Annual_Report___2022_23__2__bWICfx_87/predict_table_output'
    fld_table = sorted(list(filter(lambda x: os.path.isdir(os.path.join(predict_fld_path,x)),os.listdir(predict_fld_path))))

    predict_row_col_path = predict_fld_path.replace(PREDICT_IMAGE_STORE,PREDICT_ROW_COLUMN_STORE)
    predict_word_path = predict_fld_path.replace(PREDICT_IMAGE_STORE,PREDICT_WORD_STORE)

    if not os.path.exists(predict_row_col_path):
        os.makedirs(predict_row_col_path,exist_ok=True)


    for idx,fld in enumerate(fld_table):
        command = [
            "python", "table-transformer/src/inference.py", "--mode", "recognize",
            "--structure_config_path", "table-transformer/src/structure_config.json",
            "--structure_model_path", "table-transformer/model_file/TATR-v1.1-All-msft.pth",
            "--structure_device", "cpu",
            "--image_dir", os.path.join(predict_fld_path,fld),
            "--words_dir", os.path.join(predict_word_path,fld),
            "--out_dir", os.path.join(predict_row_col_path,fld),
            "--csv",
            "--visualize"
        ]

        subprocess.run(command)