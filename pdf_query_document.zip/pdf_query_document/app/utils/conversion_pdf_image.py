from app.utils.constant import IMAGE_STORE_NAME
from pdf2image import convert_from_path
import os
import re
import logging

def conversion_pdf_to_image(pdf_path:str,path_store:str)->None:
    if not os.path.exists(path_store):
        os.makedirs(path_store,)
    # poppler_path = r'C:\Users\Admin\Desktop\nRoad\Merchant_Statement\Merchant_Statement_Code_V1\Merchant_Statement_Code\poppler-0.68.0\bin'
    # images = convert_from_path(pdf_path, 300,poppler_path=poppler_path)
    images = convert_from_path(pdf_path, 300)
    for i, image in enumerate(images):
        fname = os.path.join(path_store,'image'+str(i)+'.jpg')
        image.save(fname, "JPEG")


def calling_conversion(pdf_path:str)->str:
    # pdf_path = r'C:\Users\Admin\Downloads\Annual-Report-Template.pdf'
    print()
    print("Converting PDF to Images")
    pdf_name = re.sub('\.pdf','',os.path.split(pdf_path)[-1])
    pdf_image_path_fld = os.path.join(IMAGE_STORE_NAME,pdf_name,'images')
    if not os.path.exists(pdf_image_path_fld):
        os.makedirs(pdf_image_path_fld,exist_ok=True)
    conversion_pdf_to_image(pdf_path=pdf_path,path_store=pdf_image_path_fld)
    print(f"Converted Images Stored at : {pdf_image_path_fld}")
    print()
    return pdf_image_path_fld