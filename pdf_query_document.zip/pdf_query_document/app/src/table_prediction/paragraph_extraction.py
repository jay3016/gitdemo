from app.utils.constant import PARAGRAPH_EXTRACT,PREDICT_IMAGE_STORE
import fitz  # PyMuPDF
import re
import os

def paragraph(pdf_path,predict_fld_path):
    paragraph_path = predict_fld_path.replace(PREDICT_IMAGE_STORE,PARAGRAPH_EXTRACT)
    if not os.path.exists(paragraph_path):
        os.makedirs(paragraph_path,exist_ok=True)
    # Open the PDF file
    # pdf_path = "/Users/bhairavjain/Desktop/research_paper/Annual_Report___2022_23__2__bWICfx_106_107.pdf"
    doc = fitz.open(pdf_path)
    
    # Extract text from each page
    for page_num in range(doc.page_count):
        page = doc.load_page(page_num)
        text = page.get_text("text")
        text = text.split('\n\t\n')
        text = list(map(lambda x:x.replace('\n',' ').replace('\t',' ').strip(),text))
        text = list(map(lambda x:re.sub('\s{2,}',' ',x,re.I).strip(),text))
        text = list(filter(lambda x:x!='',text))
        with open(os.path.join(paragraph_path,'Page_'+str(page_num+1)+'.txt'), "w") as outfile:
            outfile.write("\n".join(str(item) for item in text))
    print("Paragraph Path --> ",paragraph_path)