from app.utils.constant import IMAGE_STORE_NAME
from app.utils.constant import PREDICT_IMAGE_STORE
import os
import numpy as np
from ultralyticsplus import YOLO, render_result
from PIL import Image

# load model
#model = YOLO('keremberke/yolov8m-table-extraction')
model = YOLO('/root/gitdemo/pdf_query_document/yolov8n.pt')

# set model parameters
model.overrides['conf'] = 0.25  # NMS confidence threshold
model.overrides['iou'] = 0.45  # NMS IoU threshold
model.overrides['agnostic_nms'] = False  # NMS class-agnostic
model.overrides['max_det'] = 1000  # maximum number of detections per image

# images_path = 'pdf_ouptut/Annual-Report-Template/images'
def table_preidct_crop(images_path:str)->str:
    predict_table_path = images_path.replace('images',PREDICT_IMAGE_STORE)
    predict_fld_path = ''
    for images_list in os.listdir(images_path):
        print("Images --> ",images_list)
        predict_fld_path = os.path.join(predict_table_path,images_list.replace('.jpg',''))
        if not os.path.exists(predict_fld_path):
            os.makedirs(predict_fld_path)
        # image = 'pdf_ouptut/Annual-Report-Template/images/'+images_list
        image = os.path.join(images_path,images_list)
        print("Images --> ",image)
        img = Image.open(image)

        # perform inference
        results = model.predict(img)

        print("Number of Table Predicted -- ",len(results[0].boxes.data.numpy()))

        for idx,_ in enumerate(results[0].boxes.data.numpy()):
            x1, y1, x2, y2, _, _ = tuple(int(item) for item in results[0].boxes.data.numpy()[idx])
            img = np.array(Image.open(image))

            cropped_image = img[y1:y2, x1:x2]
            cropped_image = Image.fromarray(cropped_image)
            file_name = os.path.join(predict_fld_path,'predict_table_'+str(idx+1)+'.jpg')
            cropped_image.save(file_name)
    
    return predict_table_path