from app.utils.constant import PREDICT_WORD_STORE,PREDICT_IMAGE_STORE
from PIL import Image
import pytesseract
from pytesseract import Output
import json
import os


def table_word_coordinate(predict_table_images:str)->str:
    predict_word_path = predict_table_images.replace(PREDICT_IMAGE_STORE,PREDICT_WORD_STORE)
    for word_path in sorted(list(filter(lambda x: os.path.isdir(os.path.join(predict_table_images,x)),os.listdir(predict_table_images)))):

        if not os.path.exists(os.path.join(predict_word_path,word_path)):
            os.makedirs(os.path.join(predict_word_path,word_path),exist_ok=True)
        for predict_word_json in sorted(list(filter(lambda x: os.path.isdir(os.path.join(predict_table_images,word_path,x)),os.listdir(os.path.join(predict_table_images,word_path))))):
            for idx,name in enumerate(os.listdir(os.path.join(predict_table_images,word_path,predict_word_json))):
                
                if not os.path.exists(os.path.join(predict_word_path,word_path,predict_word_json)):
                    os.makedirs(os.path.join(predict_word_path,word_path,predict_word_json),exist_ok=True)

                cropped_image = Image.open(os.path.join(predict_table_images,word_path,predict_word_json,name))

                word_json_name = name.replace('.jpg','_words.json')

                ext_df = pytesseract.image_to_data(cropped_image, output_type=Output.DATAFRAME, config="--psm 6")

                ext_df = ext_df[ext_df['level']==5]

                sub_ext_df = ext_df[['left', 'top', 'width', 'height', 'text']]

                left_list = sub_ext_df['left'].tolist()
                top_list = sub_ext_df['top'].tolist()
                width_list = sub_ext_df['width'].tolist()
                height_list = sub_ext_df['height'].tolist()
                text_list = sub_ext_df['text'].tolist()

                word_dict = []

                for idx,_ in enumerate(left_list):
                        temp = {
                                'bbox' : [left_list[idx],top_list[idx],left_list[idx]+width_list[idx],top_list[idx]+height_list[idx]],
                                'text' : str(text_list[idx])
                        }
                        word_dict.append(temp)
                
                with open(os.path.join(predict_word_path,word_path,predict_word_json,word_json_name),'w') as f:
                        json.dump(word_dict,f,indent=4)
    return predict_word_path