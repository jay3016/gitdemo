**DE⫶TR**: End-to-End Object Detection with Transformers
========
PyTorch training code and pretrained models for **DETR** (**DE**tection **TR**ansformer).

# License
DETR is released under the Apache 2.0 license. Please see the [LICENSE](LICENSE) file for more information.
