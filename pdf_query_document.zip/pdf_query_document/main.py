from app.utils.conversion_pdf_image import calling_conversion
from app.src.table_prediction.table_predict import table_preidct_crop
from app.src.table_prediction.word_predict import table_word_coordinate
from app.src.table_prediction.table_row_column_extraction import predict_table_row_col
from app.src.table_prediction.paragraph_extraction import paragraph

# pdf_path="/Users/bhairavjain/Desktop/research_paper/Annual_Report___2022_23__2__bWICfx_87.pdf"
# pdf_path="/Users/bhairavjain/Desktop/research_paper/Annual_Report___2022_23__2__bWICfx_87.pdf"
pdf_path="/Users/bhairavjain/Desktop/research_paper/sample_pg2.pdf"
print("PDF to Image Conversion")
# images_path = calling_conversion(pdf_path = r'/Users/bhairavjain/Desktop/building_object_detection_module/Annual-Report-Template.pdf')
# images_path = calling_conversion(pdf_path="/Users/bhairavjain/Desktop/research_paper/Annual_Report___2022_23__2__bWICfx_87.pdf")
images_path = calling_conversion(pdf_path=pdf_path)
# images_path = calling_conversion(pdf_path="/Users/bhairavjain/Desktop/research_paper/Annual_Report___2022_23__2__bWICfx_105.pdf")
print("!!!!!!!!!!!!!!!!!!!!!!!")
print("Table Prediction")
predict_fld_path = table_preidct_crop(images_path)
print("predict_fld_path --> ",predict_fld_path)
print("!!!!!!!!!!!!!!!!!!!!!!!")

print("Word Prediction using Tesseract")
predict_word_path = table_word_coordinate(predict_fld_path)
print("predict_word_path --> ",predict_word_path)
print("!!!!!!!!!!!!!!!!!!!!!!!")

print("Table Row Column Extraction Table Transformer")
predict_table_row_col(predict_fld_path)
print("!!!!!!!!!!!!!!!!!!!!!!!")

print("Paragraph Extraction")
paragraph(pdf_path,predict_fld_path)
print("!!!!!!!!!!!!!!!!!!!!!!!")